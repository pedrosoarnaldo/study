set feedback off
set echo off
set head off
set server output on

alter system switch logfile;

exit;
